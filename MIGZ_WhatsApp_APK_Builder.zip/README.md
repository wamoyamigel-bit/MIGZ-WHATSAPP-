# MIGZ WhatsApp — Android APK build project

This project is configured to build a debug APK automatically with GitHub Actions.

## Build from an Android phone (no computer needed)
1. Download and extract this ZIP using your phone's Files app.
2. In Chrome, open https://github.com and sign in or create a GitHub account.
3. Create a new **public** repository named `MIGZ-WhatsApp` (do not add a README or license).
4. Use the repository's **Add file → Upload files** option and upload the extracted project contents, including the hidden `.github` folder. If your phone's file picker hides `.github`, use GitHub's web editor to create `.github/workflows/build-apk.yml` from the file in this project.
5. Commit the files to the `main` branch. GitHub Actions should start the workflow automatically.
6. Open the repository's **Actions** tab, select **Build MIGZ WhatsApp APK**, open the latest successful run, then download the artifact named **MIGZ-WhatsApp-APK**.
7. Extract the downloaded artifact ZIP. Tap `app-debug.apk` and allow installation from your browser/files app if Android asks.

## What this app does
- Displays a custom contact shortcut list.
- Tapping a contact opens the official WhatsApp conversation through `wa.me`.
- Includes local theme, font and wallpaper choices.

## Important limits
This is an independent companion app, not a replacement for WhatsApp. It cannot read WhatsApp messages or change WhatsApp's own chats, calls, status, encryption, privacy settings, or themes. Contact shortcuts are stored only in the app and currently reset when the app is closed (customization choices persist). The debug APK is unsigned for Play Store release but can be installed manually. This source has not been built or tested in this environment; the online build must succeed before an APK exists.
