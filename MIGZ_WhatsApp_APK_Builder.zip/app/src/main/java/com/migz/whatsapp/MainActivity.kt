package com.migz.whatsapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext

data class Person(val name: String, val phone: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("migz_settings", MODE_PRIVATE)
        setContent {
            var theme by remember { mutableStateOf(prefs.getString("theme", "Green") ?: "Green") }
            var font by remember { mutableStateOf(prefs.getString("font", "Sans") ?: "Sans") }
            var wallpaper by remember { mutableStateOf(prefs.getString("wallpaper", "Default") ?: "Default") }
            var showAdd by remember { mutableStateOf(false) }
            var showSettings by remember { mutableStateOf(false) }
            var name by remember { mutableStateOf("") }
            var phone by remember { mutableStateOf("") }
            val people = remember { mutableStateListOf(Person("WhatsApp support", "254700000000")) }
            val context = LocalContext.current
            val accent = when (theme) {
                "Ocean" -> Color(0xFF087EAA)
                "Purple" -> Color(0xFF7652B5)
                "Rose" -> Color(0xFFBE4775)
                "Dark" -> Color(0xFF252525)
                else -> Color(0xFF128C7E)
            }
            val bg = if (theme == "Dark") Color(0xFF101820) else when(wallpaper) {
                "Cream" -> Color(0xFFFFF4E5)
                "Sky" -> Color(0xFFEAF6FF)
                "Lavender" -> Color(0xFFF3EDFF)
                else -> Color(0xFFF6F7F8)
            }
            val family = when(font) {
                "Serif" -> FontFamily.Serif
                "Monospace" -> FontFamily.Monospace
                "Cursive" -> FontFamily.Cursive
                else -> FontFamily.SansSerif
            }
            MaterialTheme(colorScheme = lightColorScheme(primary = accent, background = bg)) {
                Surface(Modifier.fillMaxSize(), color = bg) {
                    Column(Modifier.fillMaxSize()) {
                        Row(
                            Modifier.fillMaxWidth().background(accent).padding(horizontal = 18.dp, vertical = 18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("MIGZ WhatsApp", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold, fontFamily = family)
                                Text("Your WhatsApp companion", color = Color.White.copy(alpha=.85f), fontSize = 12.sp)
                            }
                            IconButton(onClick = { showSettings = true }) {
                                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                            }
                        }
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Contacts", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), color = if(theme=="Dark") Color.White else Color(0xFF202124), fontFamily = family)
                            FilledTonalButton(onClick = { showAdd = true }) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(Modifier.width(4.dp))
                                Text("Add")
                            }
                        }
                        LazyColumn(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            items(people) { person ->
                                Card(
                                    Modifier.fillMaxWidth().clickable {
                                        val digits = person.phone.filter { it.isDigit() }
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits"))
                                        context.startActivity(intent)
                                    },
                                    colors = CardDefaults.cardColors(containerColor = if(theme=="Dark") Color(0xFF1D2A33) else Color.White),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(48.dp).background(accent.copy(alpha=.16f), CircleShape), contentAlignment = Alignment.Center) {
                                            Text(person.name.take(1).uppercase(), color = accent, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(person.name, fontWeight = FontWeight.SemiBold, fontFamily = family, color = if(theme=="Dark") Color.White else Color(0xFF202124))
                                            Text("+${person.phone}", fontSize = 12.sp, color = Color.Gray)
                                        }
                                        Text("Open", color = accent, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        Text("Chats open in the official WhatsApp app.", Modifier.align(Alignment.CenterHorizontally).padding(14.dp), fontSize = 11.sp, color = Color.Gray)
                    }
                }
                if (showAdd) AlertDialog(
                    onDismissRequest = { showAdd = false },
                    title = { Text("Add contact") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(name, { name = it }, label = { Text("Contact name") }, singleLine = true)
                            OutlinedTextField(phone, { phone = it }, label = { Text("Phone with country code") }, singleLine = true)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            if (name.isNotBlank() && phone.filter { it.isDigit() }.length >= 8) {
                                people.add(Person(name.trim(), phone.filter { it.isDigit() }))
                                name = ""; phone = ""; showAdd = false
                            }
                        }) { Text("Save") }
                    },
                    dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
                )
                if (showSettings) AlertDialog(
                    onDismissRequest = { showSettings = false },
                    title = { Text("MIGZ customization") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Theme")
                            listOf("Green", "Ocean", "Purple", "Rose", "Dark").forEach { option ->
                                FilterChip(selected = theme == option, onClick = {
                                    theme = option; prefs.edit().putString("theme", option).apply()
                                }, label = { Text(option) })
                            }
                            Divider()
                            Text("Font")
                            listOf("Sans", "Serif", "Monospace", "Cursive").forEach { option ->
                                FilterChip(selected = font == option, onClick = {
                                    font = option; prefs.edit().putString("font", option).apply()
                                }, label = { Text(option) })
                            }
                            Divider()
                            Text("Wallpaper")
                            listOf("Default", "Cream", "Sky", "Lavender").forEach { option ->
                                FilterChip(selected = wallpaper == option, onClick = {
                                    wallpaper = option; prefs.edit().putString("wallpaper", option).apply()
                                }, label = { Text(option) })
                            }
                            Text("These settings change MIGZ WhatsApp only, not official WhatsApp.", fontSize = 11.sp, color = Color.Gray)
                        }
                    },
                    confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done") } }
                )
            }
        }
    }
}
